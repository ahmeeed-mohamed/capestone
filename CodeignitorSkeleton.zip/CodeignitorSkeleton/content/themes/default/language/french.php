<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['by'] = 'par';

// Menus.
$lang['main_menu']    = 'Menu principal';
$lang['footer_menu']  = 'Menu pied de page';
$lang['sidebar_menu'] = 'Menu barre latérale';

$lang['theme_sidebar_heading'] = 'Titre traduit';
