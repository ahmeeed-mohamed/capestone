<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['by'] = 'By';

// Menus.
$lang['main_menu']    = 'Site Main Menu';
$lang['footer_menu']  = 'Site Footer Menu';
$lang['sidebar_menu'] = 'Site Sidebar Menu';

$lang['theme_sidebar_heading'] = 'Translated Heading';
